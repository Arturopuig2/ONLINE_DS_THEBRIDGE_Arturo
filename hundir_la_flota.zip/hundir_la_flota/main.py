from utils import *

print("BIENVENIDO AL JUEGO DE HUNDIR LA FLOTA")

#1 CREAMOS TABLERO

print("Vamos a crear el tablero de juego")

filas=input("Indica filas:")
columnas=input("Indica columnas:")
print(" "*20)

print("Hay dos barcos, uno de 3 bloques y otro de 4")
print("¡ENCUÉNTRALOS!")

tablero=crear_tablero(filas,columnas)


#2 PONEMOS LOS BARCOS

barco1 = [(0,1), (1,1), (2,1)]
barco2 = [(1,3), (1,4), (1,5), (1,6)]

for barco in [barco1, barco2]:
    coloca_barco(tablero,barco)

    tablero = coloca_barco(tablero, barco)

print(tablero)

#3 DISPARAMOS

contador=0
contador_aciertos=0
total_disparos=5
print(f"Llevas {contador} disparos de {total_disparos}.")
print("¡Te toca disparar!")

#FLUJO / BUCLE DE JUEGO

while contador<total_disparos:
    print("Nuevo disparo")

    fila = input("Indica la fila:")
    columna = input("Indica la columna:")
    
    # Crear una tupla de índices enteros (numpy requiere índices enteros, no string)
    coordenada = (int(fila), int(columna))

    print(coordenada)
        
    disparo=recibir_disparo(tablero, coordenada)
    contador+=1
    
    if disparo==True:
        contador_aciertos+=1

    print("Así está el juego")
    
    print(f"Llevas {contador} disparos de {total_disparos}.")
    
    print(f"Aciertos:{contador_aciertos}")
    print(" ")

    print(tablero)
    print(" ")

print("Has llegado al límite de disparos.")
print("RESUMEN DE LA PARTIDA")
print(f"Aciertos:{contador_aciertos}")
print("_"*20)