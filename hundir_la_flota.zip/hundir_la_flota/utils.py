import numpy as np 
import random
import time

# FUNCIÓN CREAR TABLERO
def crear_tablero(filas,columnas):
    filas=int(filas)
    columnas=int(columnas)
    tablero = np.full((filas, columnas), " ")
    return tablero

# FUNCIÓN POSICIONAR BARCOS
def coloca_barco(tablero,barco):
    for pieza in barco:
        tablero[pieza] = "O"
    return tablero

    tablero = coloca_barco(tablero, barco)

def recibir_disparo(tablero, coordenada):
    # Si en esa casilla hay un "O" significa que había parte de un barco
    if tablero[coordenada] == "O":
        tablero[coordenada] = "X"   # Marcamos que fue tocado
        time.sleep(1)               #Le doy un poco de tiempo
        print("*" * 20)             #Le doy un poco de espacio
        print("TOCADO")             # Mensaje de acierto
        print("*" * 20)
        resultado=True
        return resultado

    # Si ya había una "X", significa que el jugador ya disparó allí
    elif tablero[coordenada] == "X":
        time.sleep(1)
        print("*" * 20)
        print("DISPARO REPETIDO")
        print("*" * 20)


    # En cualquier otro caso (espacio vacío o disparo anterior en agua)
    else:
        tablero[coordenada] = "-"   # Marcamos el fallo con un guion
        time.sleep(1)
        print("*" * 20)
        print("AGUA")               # Mensaje de fallo
        print("*" * 20)